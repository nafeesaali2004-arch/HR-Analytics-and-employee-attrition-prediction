# HR Analytics and Employee Attrition Prediction

In this project, I developed Machine Learning Models to predict the Employee Attrition by implementing various ML Algorithms

Analysed the performance of Employees using various data visualization techniques

Achieved good accuracy on the IBM Employee Attrition Dataset using Logistic Regression

Developed a GUI using Tkinter
